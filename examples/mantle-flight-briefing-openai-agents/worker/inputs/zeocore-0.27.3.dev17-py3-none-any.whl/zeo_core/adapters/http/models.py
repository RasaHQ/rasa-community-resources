"""
Request/Response models for the HTTP adapter.
"""

from typing import Any

from pydantic import BaseModel, HttpUrl


class JobRequest(BaseModel):
    """Request to create a new job."""

    op: str
    params: dict[str, Any]
    callback_url: HttpUrl | None = None
    idempotency_key: str | None = None


class JobResponse(BaseModel):
    """Response when creating a job."""

    job_id: str
    status: str = "queued"


class JobStatus(BaseModel):
    """Status of a job."""

    job_id: str
    status: str  # queued|running|done|error
    result: dict[str, Any] | None = None
    error: str | None = None
