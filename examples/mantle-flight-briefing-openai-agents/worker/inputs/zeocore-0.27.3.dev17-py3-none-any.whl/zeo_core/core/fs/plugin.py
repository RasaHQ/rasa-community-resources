from typing import Any, Protocol, TypeVar

from zeo_core.core.fs.protocols import FsPathLike
from zeo_core.core.fs.results import (
    DataResult,
    OperationResult,
    ReadResult,
    WriteResult,
)
from zeo_core.core.fs.service import FileSystemService, get_service

T = TypeVar("T")


class FSPlugin(Protocol):
    """
    Plugin protocol for filesystem operations.
    All methods accept FsPathLike for maximum flexibility.
    """

    @property
    def name(self) -> str: ...

    def read_text(
        self, path: FsPathLike, encoding: str = "utf-8"
    ) -> ReadResult[str]: ...

    def write_text(
        self,
        path: FsPathLike,
        content: str,
        encoding: str = "utf-8",
        atomic: bool = True,
    ) -> WriteResult: ...

    def read_yaml(self, path: FsPathLike) -> DataResult[dict[str, Any]]: ...

    def write_yaml(
        self, path: FsPathLike, data: dict[str, Any], atomic: bool = True
    ) -> WriteResult: ...

    def create_directory(
        self, path: FsPathLike, exist_ok: bool = True
    ) -> OperationResult: ...


class ZeoFSPlugin:
    """
    Concrete filesystem plugin implementation.
    Delegates to FileSystemService.
    """

    def __init__(self, service: FileSystemService | None = None) -> None:
        self._service = service if service else get_service()

    @property
    def name(self) -> str:
        return "fs"

    def read_text(self, path: FsPathLike, encoding: str = "utf-8") -> ReadResult[str]:
        return self._service.read_text(path, encoding)

    def write_text(
        self,
        path: FsPathLike,
        content: str,
        encoding: str = "utf-8",
        atomic: bool = True,
    ) -> WriteResult:
        return self._service.write_text(path, content, encoding, atomic)

    def read_yaml(self, path: FsPathLike) -> DataResult[dict[str, Any]]:
        return self._service.read_yaml(path)

    def write_yaml(
        self, path: FsPathLike, data: dict[str, Any], atomic: bool = True
    ) -> WriteResult:
        return self._service.write_yaml(path, data, atomic)

    def create_directory(
        self, path: FsPathLike, exist_ok: bool = True
    ) -> OperationResult:
        return self._service.create_directory(path, exist_ok)


def create_plugin() -> FSPlugin:
    """Factory function to create filesystem plugin."""
    return ZeoFSPlugin()
