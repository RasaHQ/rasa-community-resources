import os
import shutil
from pathlib import Path


def _get_disk_usage(path: Path) -> dict[str, int]:
    try:
        total, used, free = shutil.disk_usage(str(path))
        return {"total": total, "used": used, "free": free}
    except Exception as e:
        raise OSError(f"Error getting disk usage: {e}") from e


def _probe_path_writeable(path: Path) -> bool:
    """
    Checks if a path is writeable by attempting to modify it (side-effect).
    If the path does not exist, it attempts to create it.
    Use with caution.
    """
    if not path.exists():
        try:
            if path.suffix:
                with open(path, "w") as _:
                    pass
                path.unlink()
            else:
                path.mkdir(parents=True)
                path.rmdir()
            return True
        except Exception:
            return False
    if path.is_file():
        return os.access(path, os.W_OK)
    if path.is_dir():
        try:
            test_file = path / f"test_write_{os.getpid()}.tmp"
            with open(test_file, "w") as _:
                pass
            test_file.unlink()
            return True
        except Exception:
            return False
    return False
