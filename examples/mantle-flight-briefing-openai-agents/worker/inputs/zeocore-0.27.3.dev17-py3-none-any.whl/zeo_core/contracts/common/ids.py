"""
ID generation utilities for contracts.

Provides standardized UUID generation for run IDs and artifact IDs.
No external dependencies beyond stdlib.
"""

import uuid
from typing import NewType

# Type aliases for clarity
RunID = NewType("RunID", str)
ArtifactID = NewType("ArtifactID", str)


def generate_run_id() -> str:
    """
    Generate a unique run identifier.

    Returns:
        UUID4 string suitable for tracking a single tool execution

    Example:
        >>> run_id = generate_run_id()
        >>> len(run_id)
        36
    """
    return str(uuid.uuid4())


def generate_invocation_id() -> str:
    """
    Generate a unique capability invocation identifier.

    Runners may supply their own ID. This helper exists for library tests
    and runners that want a UUID4 default.
    """
    return str(uuid.uuid4())


def generate_artifact_id() -> str:
    """
    Generate a unique artifact identifier.

    Returns:
        UUID4 string suitable for tracking a single artifact across storage systems

    Example:
        >>> artifact_id = generate_artifact_id()
        >>> len(artifact_id)
        36
    """
    return str(uuid.uuid4())


def is_valid_uuid(value: str) -> bool:
    """
    Validate that a string is a properly formatted UUID.

    Args:
        value: String to validate

    Returns:
        True if value is a valid UUID format

    Example:
        >>> is_valid_uuid("550e8400-e29b-41d4-a716-446655440000")
        True
        >>> is_valid_uuid("not-a-uuid")
        False
    """
    try:
        uuid.UUID(value)
        return True
    except (ValueError, AttributeError):
        return False
