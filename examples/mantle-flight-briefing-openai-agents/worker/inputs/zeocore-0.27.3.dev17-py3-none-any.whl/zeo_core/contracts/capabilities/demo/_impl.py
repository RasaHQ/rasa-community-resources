"""
Demo capability implementations (INTERNAL EXAMPLES ONLY).

⚠️ NOT FOR PRODUCTION USE ⚠️

These implementations are kept in Ring A only as minimal reference examples
to demonstrate contract usage patterns. They have no external dependencies
beyond contracts themselves.

In a real system, capability implementations belong in Ring B (zeo_core.tools).

The underscore prefix (_impl.py) marks this module as internal/private.
Do not import these functions in production code.
"""

from zeo_core.contracts.capabilities.demo.models import EchoRequest, VideoRefRequest
from zeo_core.contracts.envelopes import CapabilityResult


def echo_text(req: EchoRequest) -> CapabilityResult[str]:
    """
    Simple echo capability that returns formatted text.

    ⚠️ EXAMPLE ONLY - NOT FOR PRODUCTION USE

    Demonstrates:
    - Basic CapabilityResult.ok() usage
    - Metadata population
    - No external dependencies

    Args:
        req: Echo request with text and optional greeting

    Returns:
        CapabilityResult with formatted text

    Example:
        >>> result = echo_text(EchoRequest(text="World"))
        >>> result.status
        <CapabilityStatus.success: 'success'>
        >>> result.data
        'Hello World'
    """
    greeting = req.override_greeting or "Hello"
    final_text = f"{greeting} {req.text}"

    return CapabilityResult.ok(
        data=final_text,
        msg="Echo successful",
        metadata={"used_preset": req.preset, "greeting": greeting},
    )


def validate_video_ref(req: VideoRefRequest) -> CapabilityResult[bool]:
    """
    Validate video URL against supported providers.

    ⚠️ EXAMPLE ONLY - NOT FOR PRODUCTION USE

    Demonstrates:
    - CapabilityResult.skip() for policy decisions
    - CapabilityResult.ok() for validation success
    - Machine branching via skip codes

    Args:
        req: Video URL validation request

    Returns:
        CapabilityResult indicating validation outcome

    Example:
        >>> # Valid provider
        >>> result = validate_video_ref(VideoRefRequest(url="https://youtube.com/watch?v=abc"))
        >>> result.status
        <CapabilityStatus.success: 'success'>

        >>> # Unsupported provider
        >>> result = validate_video_ref(VideoRefRequest(url="https://example.com/video.mp4"))
        >>> result.status
        <CapabilityStatus.skipped: 'skipped'>
        >>> result.machine_message
        'ZEO_VAL_UNSUPPORTED_PROVIDER'
    """
    supported_providers = ["youtube.com", "drive.google.com", "vimeo.com"]

    # Check if URL contains any supported provider
    if not any(provider in req.url for provider in supported_providers):
        return CapabilityResult.skip(
            reason=(
                "URL is not from a supported provider. Supported: "
                f"{', '.join(supported_providers)}"
            ),
            code="ZEO_VAL_UNSUPPORTED_PROVIDER",
        )

    return CapabilityResult.ok(
        data=True, msg="Video reference is valid", metadata={"url": req.url}
    )
