"""
Boot API for ZeoCore integrations.

This is the public entry point for applications (like ZeoChat or CLI)
to explicitly load runtime dependencies. It manages a global registry instance
for convenience but allows for dependency injection.
"""

from zeo_core.integrations.core.registry import IntegrationRegistry
from zeo_core.integrations.core.results import IntegrationLoadReport
from zeo_core.integrations.loader import load_enabled_entry_points

# Global default registry (convenience for simple apps)
_global_registry = IntegrationRegistry()


def get_global_registry() -> IntegrationRegistry:
    """
    Get the global integration registry.

    Returns:
        IntegrationRegistry: The global singleton registry.
    """
    return _global_registry


def load_integrations(
    enabled: list[str],
    registry: IntegrationRegistry | None = None,
    strict: bool = True,
    initialize: bool = True,
) -> IntegrationLoadReport:
    """
    Boot specific integrations.

    Args:
        enabled: List of integration IDs (e.g. ['github', 'llms', 'google.mail'])
        registry: Optional registry instance. Defaults to global.
        strict: Whether to fail if an integration is missing.
        initialize: Whether to run .initialize() on loaded integrations.

    Returns:
        IntegrationLoadReport: Result of the load operation.
    """
    target_registry = registry or _global_registry

    return load_enabled_entry_points(
        registry=target_registry, enabled=enabled, strict=strict, initialize=initialize
    )
