"""
Base classes for ZeoCore integrations.

This module provides abstract base classes that integration implementations
can inherit from, providing common functionality and ensuring
consistent behavior.
"""

import os
from abc import ABC, abstractmethod
from pathlib import Path
from types import ModuleType
from typing import Any

from zeo_core.core.errors import ZeoConfigurationError
from zeo_core.core.fs.normalize import coerce_path, coerce_path_str
from zeo_core.core.logging import LOG_LEVELS, LogLevel, get_logger
from zeo_core.integrations.core.protocols import (
    AuthProviderProtocol,
    ConfigProviderProtocol,
    IntegrationProtocol,
)
from zeo_core.integrations.core.results import (
    AuthResult,
    ConfigResult,
    IntegrationResult,
)
from zeo_core.integrations.environment import managed_path, managed_state_dir


class BaseAuthProvider(ABC, AuthProviderProtocol):
    """Base class for authentication providers."""

    def __init__(
        self,
        credentials_file: str | None = None,
        log_level: int = LOG_LEVELS[LogLevel.INFO],
    ) -> None:
        self.logger = get_logger(f"{__name__}.{self.__class__.__name__}")
        self.logger.setLevel(log_level)

        self.credentials_file = (
            self._resolve_path(credentials_file) if credentials_file else None
        )
        self.authenticated = False

    def _resolve_path(self, file_path: str) -> str:
        if managed_state_dir() is not None:
            return managed_path(file_path)
        try:
            from zeo_core.core.fs.service import standalone

            result = standalone.resolve_path(file_path)
            return coerce_path_str(result)
        except Exception as e:
            # standalone.resolve_path is an alias for standalone.normalize_path
            # (service/path_operations.py) -- both are sandboxed to the same
            # FileSystemService base_dir, so a retry via normalize_path here
            # would fail identically for the same input (e.g. a credentials_file
            # legitimately living outside the sandbox, per RULING-237 s2.1). Match
            # BaseConfigProvider._resolve_path's own established fallback shape
            # (below in this file): log and fall back to the raw, unresolved path
            # rather than repeating the identical sandboxed call or silently
            # returning None -- a credentials path that fails to resolve is still
            # usable to the OS directly, and swallowing it to None would be a
            # quieter, worse bug than surfacing the unresolved path.
            self.logger.warning(f"Could not resolve credentials path: {e}")
            return file_path

    @property
    @abstractmethod
    def name(self) -> str: ...

    @abstractmethod
    def authenticate(self) -> AuthResult: ...

    @abstractmethod
    def refresh_credentials(self) -> AuthResult: ...

    @abstractmethod
    def get_credentials(self) -> object: ...

    def save_credentials(self) -> bool:
        self.logger.warning(
            "save_credentials() not implemented in base class. Override in subclass."
        )
        return False

    def _ensure_credentials_directory(self) -> bool:
        if not self.credentials_file:
            return False
        try:
            from zeo_core.core.fs.service import standalone

            cred_path = coerce_path(self.credentials_file)
            parent_dir = cred_path.parent
            result = standalone.create_directory(parent_dir, exist_ok=True)
            return getattr(result, "success", False)
        except Exception as e:
            self.logger.error(f"Unexpected error creating credentials directory: {e}")
            return False


class BaseConfigProvider(ABC, ConfigProviderProtocol):
    """Base class for configuration providers."""

    DEFAULT_CONFIG_LOCATIONS = [
        "./config/integration_config.yaml",
        "./zeo_config.yaml",
        "~/.zeo/config.yaml",
    ]

    def __init__(self, log_level: int = LOG_LEVELS[LogLevel.INFO]) -> None:
        self.logger = get_logger(f"{__name__}.{self.__class__.__name__}")
        self.logger.setLevel(log_level)

    @property
    @abstractmethod
    def name(self) -> str: ...

    def load_config(self, config_path: str | None = None) -> ConfigResult:
        from zeo_core.core.fs.service import (
            FileSystemService,
            create_service,
            standalone,
        )

        file_service: FileSystemService | ModuleType

        state = managed_state_dir()
        if state is not None:
            config_path = managed_path(
                config_path or str(state / "config" / "integrations.yaml")
            )
            file_service = create_service(base_dir=str(Path(config_path).parent))
        else:
            file_service = standalone

        if not config_path:
            config_path = self._find_config_file()
            if not config_path:
                raise ZeoConfigurationError(
                    "Configuration file not found in default locations."
                )

        config_path_str = coerce_path_str(config_path)

        file_info = file_service.get_file_info(config_path_str)
        if not file_info.success or not file_info.exists:
            raise ZeoConfigurationError(
                f"Configuration file not found: {config_path_str}",
                config_path=config_path_str,
            )

        yaml_result = file_service.read_yaml(config_path_str)
        if not yaml_result.success:
            raise ZeoConfigurationError(
                f"Failed to read YAML configuration: {yaml_result.error}",
                config_path=config_path_str,
            )

        config_data = yaml_result.data
        if config_data is None:
            raise ZeoConfigurationError(
                f"Configuration file loaded but contained no data: {config_path_str}",
                config_path=config_path_str,
            )
        integration_config = self._extract_config(config_data)

        if not self.validate_config(integration_config):
            return ConfigResult.error_result("Configuration validation failed")

        return ConfigResult.success_result(
            content=integration_config,
            message="Successfully loaded configuration",
            config_path=config_path_str,
        )

    def _extract_config(self, config_data: dict[str, Any]) -> dict[str, Any]:
        integration_name = self.name.lower().replace(" ", "_")
        section = config_data.get(integration_name, {})
        if not isinstance(section, dict):
            raise ZeoConfigurationError(
                f"Configuration section '{integration_name}' must be a mapping, "
                f"got {type(section).__name__}"
            )
        return section

    def _config_path_from_env_var(self) -> str | None:
        """
        Step 1 of _find_config_file: check the ZEO_<NAME>_CONFIG env var.
        Extracted to keep _find_config_file's own branch count under the
        C901 threshold; behavior/order unchanged.
        """
        from zeo_core.core.fs.service import standalone

        env_var = f"ZEO_{self.name.upper()}_CONFIG"
        if config_path := os.environ.get(env_var):
            expanded_path = standalone.expand_user_vars(config_path)
            path_str = coerce_path_str(expanded_path)
            file_info = standalone.get_file_info(path_str)
            if file_info.success and file_info.exists:
                return path_str
        return None

    def _resolve_project_root_for_config(self) -> Path | None:
        """
        Step 2 of _find_config_file: best-effort project root lookup.
        Extracted for the same C901 reason as _config_path_from_env_var.
        """
        try:
            from zeo_core.core.paths import service as paths

            if hasattr(paths, "get_project_root"):
                root_result = paths.get_project_root()
                if root_result.success:
                    # Explicitly use .path from result for strict correctness
                    return coerce_path(root_result.path)
        except Exception as e:
            self.logger.debug(
                f"Project root lookup failed, checking only direct paths: {e}"
            )
        return None

    def _config_path_from_default_locations(
        self, project_root: Path | None
    ) -> str | None:
        """
        Step 3 of _find_config_file: check DEFAULT_CONFIG_LOCATIONS, anchoring
        relative candidates to project_root when available. Extracted for the
        same C901 reason as _config_path_from_env_var.
        """
        from zeo_core.core.fs.service import standalone

        for location in self.DEFAULT_CONFIG_LOCATIONS:
            expanded = standalone.expand_user_vars(location)
            candidate_path = coerce_path(expanded)

            if not candidate_path.is_absolute() and project_root:
                candidate_path = project_root / candidate_path

            candidate_str = coerce_path_str(candidate_path)
            file_info = standalone.get_file_info(candidate_str)
            if file_info.success and file_info.exists:
                return candidate_str
        return None

    def _config_path_from_project_root_fallback(
        self, project_root: Path | None
    ) -> str | None:
        """
        Step 4 of _find_config_file: project_root/zeo_config.yaml fallback.
        Extracted for the same C901 reason as _config_path_from_env_var.
        """
        from zeo_core.core.fs.service import standalone

        if project_root:
            fallback = project_root / "zeo_config.yaml"
            fallback_str = coerce_path_str(fallback)
            file_info = standalone.get_file_info(fallback_str)
            if file_info.success and file_info.exists:
                return fallback_str
        return None

    def _find_config_file(self) -> str | None:
        if state := managed_state_dir():
            candidate = state / "config" / "integrations.yaml"
            return managed_path(str(candidate)) if candidate.is_file() else None
        if path := self._config_path_from_env_var():
            return path

        project_root = self._resolve_project_root_for_config()

        if path := self._config_path_from_default_locations(project_root):
            return path

        return self._config_path_from_project_root_fallback(project_root)

    def _resolve_path(self, file_path: str) -> str:
        if managed_state_dir() is not None:
            return managed_path(file_path)
        try:
            from zeo_core.core.fs.service import standalone

            result = standalone.resolve_path(file_path)
            return coerce_path_str(result)
        except Exception as e:
            self.logger.warning(f"Could not resolve project path: {e}")
            return file_path

    @abstractmethod
    def validate_config(self, config: dict[str, Any]) -> bool: ...

    @abstractmethod
    def get_default_config(self) -> dict[str, Any]: ...


class BaseIntegrationService(ABC, IntegrationProtocol):
    """Base class for integration services."""

    def __init__(
        self,
        config_provider: ConfigProviderProtocol | None = None,
        auth_provider: AuthProviderProtocol | None = None,
        config: dict[str, Any] | None = None,
        config_path: str | None = None,
        log_level: int = LOG_LEVELS[LogLevel.INFO],
    ) -> None:
        self.logger = get_logger(f"{__name__}.{self.__class__.__name__}")
        self.logger.setLevel(log_level)
        self.log_level = log_level

        self.config_provider = config_provider
        self.auth_provider = auth_provider
        self.config = config
        self._initialized = False

        self.config_path: str | None = None
        if config_path:
            self._set_config_path(config_path)

    def _set_config_path(self, config_path: str) -> None:
        if managed_state_dir() is not None:
            self.config_path = managed_path(config_path)
            return
        self.config_path = config_path
        try:
            from zeo_core.core.fs.service import standalone

            result = standalone.resolve_path(config_path)
            self.config_path = coerce_path_str(result)
            self.logger.debug(f"Set config path to {self.config_path}")
        except Exception as e:
            self.logger.error(f"Error setting config path: {e}")
            self.config_path = config_path

    @property
    @abstractmethod
    def name(self) -> str: ...

    @property
    def integration_id(self) -> str:
        return self.name.lower().replace(" ", ".")

    @property
    def version(self) -> str:
        return "1.0.0"

    def initialize(self) -> IntegrationResult:
        if self._initialized:
            self.logger.debug(f"{self.integration_id} integration already initialized")
            return IntegrationResult.success_result(
                message=f"{self.name} integration already initialized"
            )

        try:
            if not self.config and self.config_provider:
                config_result = self.config_provider.load_config(self.config_path)
                if not config_result.success:
                    raise ZeoConfigurationError(
                        f"Failed to load configuration: {config_result.error}",
                        config_path=self.config_path,
                    )
                self.config = config_result.content
                if config_result.config_path and not self.config_path:
                    self._set_config_path(config_result.config_path)

            if self.auth_provider and not getattr(
                self.auth_provider, "authenticated", False
            ):
                auth_result = self.auth_provider.authenticate()
                if not auth_result.success:
                    return IntegrationResult.error_result(
                        f"Failed to authenticate {self.name}: {auth_result.error}"
                    )

            self._initialized = True
            return IntegrationResult.success_result(
                message=f"{self.name} integration initialized successfully"
            )
        except ZeoConfigurationError as e:
            self.logger.error(f"Configuration error during initialization: {e}")
            return IntegrationResult.error_result(str(e))
        except Exception as e:
            self.logger.error(f"Failed to initialize integration: {e}")
            return IntegrationResult.error_result(
                f"Failed to initialize {self.name} integration: {str(e)}"
            )

    def is_available(self) -> bool:
        return self._initialized

    def _ensure_initialized(self) -> IntegrationResult | None:
        if not self._initialized:
            self.logger.info(f"Auto-initializing {self.name} integration")
            init_result = self.initialize()
            if not init_result.success:
                return init_result
        return None
